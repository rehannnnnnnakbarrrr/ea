<div class="container"></div>
<div class="row">
        <div class="col-md-12" mt-3>
            <div class="card">
            <div class="card-header">
                TANGGAPAN 
               <div class="card-body">
                <form action="" method="post">
                <div class="mb-3">
                    <label  class="form-label">Judul Laporan</label>
                    <input type="text" class="form-control" value="" readonly>
                </div>
                <div class="mb-3">
                    <label  class="form-label">Isi Laporan</label>
                    <textarea class="form-control" value="" readonly></textarea>
                </div>
                <div class="mb-3">
                    <label  class="form-label">Foto</label>
                    <input type="file" class="form-control" name="foto" required>
                </div>
                <div class="mb-3">
                    <label  class="form-label">Tanggapan</label>
                    <textarea class="form-control"></textarea>
                </div>
                </div>
                <div class="card-footer">
                    <a href="index.php" class="btn btn-primary">kembali</a>
                        <button type="submit" name="kirim" class="btn btn-primary">Kirim</button>
                </div>
                </form>
                </div>
        </div>
    </div>
    </div>