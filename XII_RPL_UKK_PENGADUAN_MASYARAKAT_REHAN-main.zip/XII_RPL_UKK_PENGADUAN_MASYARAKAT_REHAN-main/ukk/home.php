<div class="container">
    <h4 class="text-center mt-3">Pengaduan Masyarakat <br>Tahun 2023/2024 <br></h4>
    <hr>
    <div class="row mt-3">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">INFORMASI</div>
                <div class="card-body">
                Aplikasi pengaduan masyarakat ini dibuat untuk yang ingin membuat laporan
                </div>
                <div class="card-footer"></div>
            </div>
        </div>
    </div>
</div>