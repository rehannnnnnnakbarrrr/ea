<?php
if(!isset($_SESSION['nik'])){
	header('location:login.php');
}


?>


<div class="halaman">
	<h2>Halaman Depan</h2>
</div>