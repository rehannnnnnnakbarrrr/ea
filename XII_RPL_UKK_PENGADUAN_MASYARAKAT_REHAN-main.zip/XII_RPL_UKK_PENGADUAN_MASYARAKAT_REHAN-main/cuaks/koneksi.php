<?php

session_start();
    $db = new PDO("mysql:host=localhost;dbname=webb","root","");

    
    ?>
